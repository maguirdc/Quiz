package quiz;

public enum QuizType {
	
	CHEMISTRY, BIOLOGY, PHYSICS;

}
