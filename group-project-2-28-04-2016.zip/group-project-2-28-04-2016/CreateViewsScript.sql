DROP VIEW IF exists login_entities;

CREATE VIEW login_entities
AS
SELECT email AS Username, user_password AS Password FROM pupils
UNION
SELECT email AS Username, user_password AS Password FROM staff;



DROP VIEW IF exists login_staff;

CREATE VIEW login_staff
AS
SELECT email AS Username, access_level AS Access_level, user_password AS Password
FROM staff;


DROP VIEW IF exists login_admins;


CREATE VIEW login_admins
AS
SELECT email AS Username, access_level AS Access_level, user_password AS Password
FROM staff 
WHERE Access_LEVEL = 'Admin';


DROP VIEW IF exists login_teachers;

CREATE VIEW login_teachers
AS
SELECT email AS Username, access_level AS Access_level, user_password AS Password
FROM staff 
WHERE Access_LEVEL = 'Teaching';


DROP VIEW IF exists login_students;


CREATE VIEW login_pupils
AS
SELECT email AS Username, user_password AS Password
FROM pupils;



