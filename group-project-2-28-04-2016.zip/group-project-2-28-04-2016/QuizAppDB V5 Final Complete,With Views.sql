SET foreign_key_checks = 0;

DROP TABLE IF exists physics_answers;
DROP TABLE IF exists physics_questions;
DROP TABLE IF exists staff;
DROP TABLE IF exists subject_category;
DROP TABLE IF exists class;
DROP TABLE IF exists guardians;
DROP TABLE IF exists pupils;
DROP TABLE IF exists quiz;
DROP TABLE IF exists biology_answers;
DROP TABLE IF exists biology_questions;
DROP TABLE IF exists chemistry_answers;
DROP TABLE IF exists chemistry_questions;
DROP TABLE IF exists score;

SET foreign_key_checks = 1;

CREATE TABLE staff (

   staff_id			VARCHAR(8) 		NOT NULL,
   first_name 		VARCHAR(20) 	NOT NULL,
   last_name 		VARCHAR(20) 	NOT NULL,
   position			VARCHAR(20)		NOT NULL,
   access_level 	VARCHAR(20) 	NOT NULL,
   email 			VARCHAR(40) 	NOT NULL,
   user_password 	VARCHAR(12) 	NOT NULL,
       
    PRIMARY KEY (staff_id)
	 
);

CREATE TABLE subject_category (

	subject_id 		VARCHAR(8) 	 	NOT NULL,
	subject_title 	VARCHAR(20) 	NOT NULL,

	PRIMARY KEY (subject_id)

);

CREATE TABLE class (

	class_id 		VARCHAR(8) 		NOT NULL,
	staff_id 		VARCHAR(8) 		NOT NULL,
	subject_id 		VARCHAR(8) 		NOT NULL,

	PRIMARY KEY (class_id),
	FOREIGN KEY (staff_id) REFERENCES staff(staff_id)

);

CREATE TABLE guardians (

	guardian_id 	VARCHAR(8) 		NOT NULL,
	first_name 		VARCHAR(20) 	NOT NULL,
	last_name 		VARCHAR(20) 	NOT NULL,
	email 			VARCHAR(40) 	NOT NULL,
	mobile_number 	VARCHAR(11) 	NOT NULL,

	PRIMARY KEY (guardian_id)

);


CREATE TABLE pupils (

	pupil_id 		VARCHAR(8) 		NOT NULL,
	first_name 		VARCHAR(20) 	NOT NULL,
	last_name 		VARCHAR(20) 	NOT NULL,
	class_id 		VARCHAR(8) 		NOT NULL,
	guardian_id 	VARCHAR(8) 		NOT NULL,
	email 			VARCHAR(40) 	NOT NULL,
    user_password   VARCHAR(12)     NOT NULL,
    enrolled		tinyint			NOT NULL,

	PRIMARY KEY (pupil_id),
	FOREIGN KEY (class_id) REFERENCES class(class_id),
	FOREIGN KEY (guardian_id) REFERENCES guardians(guardian_id)

);

CREATE TABLE quiz (

	quiz_id 		VARCHAR(8) 		NOT NULL,
	date_submitted 	date 			NOT NULL,
	staff_id 		VARCHAR(8) 		NOT NULL,

	PRIMARY KEY (quiz_id),
	FOREIGN KEY (staff_id) REFERENCES staff(staff_id)

);

CREATE TABLE physics_questions (

	physics_id 		VARCHAR(8) 		NOT NULL,
	question 		VARCHAR(1000) 	NOT NULL,
    correct_answer	VARCHAR(8)		NOT NULL,
	quiz_id 		VARCHAR(8) 		NOT NULL,

	PRIMARY KEY (physics_id),
	FOREIGN KEY (quiz_id) REFERENCES quiz(quiz_id)

);

CREATE TABLE physics_answers (

	physics_answers_id 		VARCHAR(8) 		NOT NULL,
	answers 				VARCHAR(1000) 	NOT NULL,
	correct_answer 			tinyint 		NOT NULL,
	physics_id 				VARCHAR(8) 		NOT NULL,

	PRIMARY KEY (physics_answers_id),
	FOREIGN KEY (physics_id) REFERENCES physics_questions(physics_id)

);

CREATE TABLE biology_questions (

	biology_id 		VARCHAR(8) 		NOT NULL,
	question 		VARCHAR(1000) 	NOT NULL,
    correct_answer  VARCHAR(8)		NOT NULL,
	quiz_id 		VARCHAR(8) 		NOT NULL,

	PRIMARY KEY (biology_id),
	FOREIGN KEY (quiz_id) REFERENCES quiz(quiz_id)


);

CREATE TABLE biology_answers (

	biology_answers_id 		VARCHAR(8) 		NOT NULL,
	answers 				VARCHAR(1000) 	NOT NULL,
	correct_answer 			tinyint 		NOT NULL,
	biology_id 				VARCHAR(8) 		NOT NULL,

	PRIMARY KEY (biology_answers_id),
	FOREIGN KEY (biology_id) REFERENCES biology_questions(biology_id)

);

CREATE TABLE chemistry_questions (

	chemistry_id 	VARCHAR(8) 		NOT NULL,
	question 		VARCHAR(1000) 	NOT NULL,
    correct_answer  VARCHAR(8)		NOT NULL,
	quiz_id 		VARCHAR(8) 		NOT NULL,

	PRIMARY KEY (chemistry_id),
	FOREIGN KEY (quiz_id) REFERENCES quiz(quiz_id)


);

CREATE TABLE chemistry_answers (

	chemistry_answers_id 	VARCHAR(8) 		NOT NULL,
	answers 				VARCHAR(1000) 	NOT NULL,
	correct_answer 			tinyint 		NOT NULL,
	chemistry_id 			VARCHAR(8) 		NOT NULL,

	PRIMARY KEY (chemistry_answers_id),
	FOREIGN KEY (chemistry_id) REFERENCES chemistry_questions(chemistry_id)

);

CREATE TABLE score (

	pupil_id 		VARCHAR(8) 		NOT NULL,
	quiz_id 		VARCHAR(8) 		NOT NULL,
	score 			VARCHAR(2) 		NOT NULL,
	date_taken 		date 			NOT NULL,

	FOREIGN KEY (pupil_id) REFERENCES pupils(pupil_id),
	FOREIGN KEY (quiz_id) REFERENCES quiz(quiz_id)

);



INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000001','Mari','Orr','Admin','Admin','m.orr@admin.ac.uk','Admin2016');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000002','Aurelia','Watts','Admin','Admin','a.watts@admin.ac.uk','HELLo23');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000003','Geoffrey','Page','Admin','Admin','g.page@admin.ac.uk','Teacherz1');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000004','Leigh','Thornton','Teacher','Teaching','l.thornton@teach.ac.uk','Education12');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000005','Stuart','Espinoza','Teacher','Teaching','s.espinoza@teach.ac.uk','123344fG');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000006','Unity','Perry','Department Head','Teaching','u.perry@teach.ac.uk','Cats2');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000007','Hedwig','Raymond','Department Head','Teaching','h.raymond@teach.ac.uk','hellothere1');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000008','Donovan','Jimenez','Teacher','Teaching','d.jimenez@teach.ac.uk','Admin2016');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000009','Jack','Cooper','Teacher','Teaching','j.cooper@teach.ac.uk','B0okS');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000010','Daryl','Powell','Admin','Admin','d.powell@admin.ac.uk','40041654ID');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000011','Rose','Haney','Teacher','Teaching','r.haney@teach.ac.uk','aa11BB');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000012','Sydney','Chan','Teacher','Teaching','s.chan@teach.ac.uk','starwars66');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000013','Brennan','Dickerson','Department Head','Teaching','b.dickerson@teach.ac.uk','9dontforget');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000014','Minerva','Pace','Teacher','Teaching','m.pace@teach.ac.uk','MyPa33word');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000015','Arden','Macias','Teacher','Teaching','a.macias@teach.ac.uk','enterHere1');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000016','Hasad','Rojas','Teacher','Teaching','h.rojas@teach.ac.uk','12345HELLO');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000017','Lavinia','Brady','Teacher','Teaching','l.brady@teach.ac.uk','CAPS9876');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000018','Herrod','Morin','Teacher','Teaching','h.morin@teach.ac.uk','program2');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000019','Orlando','Sharp','Teacher','Teaching','o.sharp@teach.ac.uk','Starbucks44');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000020','Blaine','Mosley','Teacher','Teaching','b.mosley@teach.ac.uk','birthday91');
INSERT INTO staff (staff_id, first_name, last_name, position, access_level, email, user_password) VALUES ('ST000021','David','Hendrix','Teacher','Teaching','d.hendrix@teach.ac.uk','jimiHen0');

INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000001','Sarah','Hyde','s.hyde@hotmail.com','07700900750');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000002','Norman','Lyons','n.lyons@gmail.co.uk','07700900658');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000003','John','Downs','j.downs@gmail.co.uk','07700900990');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000004','Bailey','Jordan','b.jordan@gmail.co.uk','07700900901');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000005','Jess','Lamb','j.lamb@gmail.co.uk','07700900986');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000006','Lisa','Carrillo','l.carrillo@gmail.co.uk','07700900969');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000007','Susie','Hatfield','s.hatfield@yahoo.co.uk','07700900946');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000008','Warren','Frazier','w.frazier@gmail.co.uk','07700900708');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000009','Liam','Morton','l.morton@bt.co.uk','07700900058');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000010','Steven','Mann','s.mann@gmail.co.uk','07700900483');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000011','Maisy','Montoya','m.montoya@gmail.co.uk','07700900143');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000012','Amy','Sweeney','a.sweeney@gmail.co.uk','07700900121');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000013','April','Fernandez','a.fernandez@gmail.co.uk','07700900132');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000014','Dave','Shepard','d.shepard@gmail.co.uk','07700900116');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000015','Paul','Sawyer','p.sawyer@gmail.co.uk','07700900368');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000016','Chris','Ballard','c.ballard@qub.ac.uk','07700900246');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000017','Andy','Emerson','a.emerson@kpmc.uk','07700900854');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000018','Lisa','Vasquez','l.vasquez@gmail.co.uk','07700900576');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000019','Pam','Riley','p.riley@gmail.co.uk','07700900073');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000020','Robert','Buckley','r.buckley@gmail.co.uk','07700900190');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000021','June','Mayo','j.mayo@gmail.co.uk','07700900441');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000022','Sasha','Garrett','s.garrett@gmail.co.uk','07700900009');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000023','Lisa','Armstrong','l.armstrong@gmail.co.uk','07700900221');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000024','Jackie','Brown','j.brown@gmail.co.uk','07700900631');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000025','Lawrence','Mcgowan','l.mcgowan@gmail.co.uk','07700900332');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000026','Julia','Boyle','j.boyle@gmail.co.uk','07700900990');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000027','Jordan','Sargent','j.sargent@gmail.co.uk','07700900440');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000028','Rebecca','Fisher','r.fisher@gmail.co.uk','07700900426');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000029','Michelle','Gallegos','m.gallegos@gmail.co.uk','07700900214');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000030','Janet','Justice','j.justice@gmail.co.uk','07700900549');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000031','Billy','Rowe','b.rowe@gmail.co.uk','07700900051');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000032','Roisin','Graham','r.graham@gmail.co.uk','07700900527');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000033','Leeann','Kim','l.kim@gmail.co.uk','07700900750');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000034','Suzanne','Bauer','s.bauer@gmail.co.uk','07700900278');
INSERT INTO guardians (guardian_id, first_name, last_name, email, mobile_number) VALUES ('GP000035','Sara ','Frost','s.frost@gmail.co.uk','07700900722');

INSERT INTO subject_category (subject_id, subject_title) VALUES ('SUB00001','Physics');
INSERT INTO subject_category (subject_id, subject_title) VALUES ('SUB00002','Biology');
INSERT INTO subject_category (subject_id, subject_title) VALUES ('SUB00003','Chemistry');

INSERT INTO class (class_id, staff_id, subject_id) VALUES ('CL000001','ST000014','SUB00001');
INSERT INTO class (class_id, staff_id, subject_id) VALUES ('CL000002','ST000015','SUB00002');
INSERT INTO class (class_id, staff_id, subject_id) VALUES ('CL000003','ST000016','SUB00003');
INSERT INTO class (class_id, staff_id, subject_id) VALUES ('CL000004','ST000004','SUB00001');
INSERT INTO class (class_id, staff_id, subject_id) VALUES ('CL000005','ST000005','SUB00002');
INSERT INTO class (class_id, staff_id, subject_id) VALUES ('CL000006','ST000021','SUB00003');

INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000001','Trevor','Hyde','CL000002','GP000001','t.hyde@pupil.ac.uk','Qzjk7xGPD',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000002','Aurelia','Lyons','CL000001','GP000002','a.lyons@pupil.ac.uk','cxf7v4fF9',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000003','Sean','Downs','CL000001','GP000003','s.downs@pupil.ac.uk','ykJfxjpuy',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000004','Jamalia','Jordan','CL000001','GP000004','j.jordan@pupil.ac.uk','jmnaT87Bd',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000005','Macy','Lamb','CL000001','GP000005','m.lamb@pupil.ac.uk','mqQU3qTS4',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000006','Brenna','Carrillo','CL000001','GP000006','b.carrillo@pupil.ac.uk','AwTzLQJPk',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000007','Craig','Hatfield','CL000001','GP000007','c.hatfield@pupil.ac.uk','eF2dkujQn',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000008','Jacqueline','Frazier','CL000001','GP000008','j.frazier@pupil.ac.uk','KuHPGzmNq',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000009','Uriah','Morton','CL000001','GP000009','u.morton@pupil.ac.uk','xcWHcvgUT',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000010','Leonard','Mann','CL000001','GP000010','l.mann@pupil.ac.uk','FPVXJGAMD',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000011','Carter','Montoya','CL000003','GP000011','c.montoya@pupil.ac.uk','hWwFePyfPJV',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000012','Cole','Sweeney','CL000003','GP000012','c.sweeney@pupil.ac.uk','YB5tRhSwqSk',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000013','Jada','Fernandez','CL000003','GP000013','j.fernandez@pupil.ac.uk','Bzt4E7dzjsV',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000014','Carl','Shepard','CL000003','GP000014','c.shepard@pupil.ac.uk','cgtc7zMqKc6',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000015','Chelsea','Sawyer','CL000003','GP000015','c.sawyer@pupil.ac.uk','G2RkSPr4MyV',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000016','Alisa','Ballard','CL000003','GP000016','a.ballard@pupil.ac.uk','fYCHCgxhPpg',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000017','Zelenia','Emerson','CL000004','GP000017','z.emerson@pupil.ac.uk','8qL36dkvXqf',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000018','Emerson','Vasquez','CL000004','GP000018','e.vasquez@pupil.ac.uk','muqdQ9F5v2W',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000019','Britanni','Riley','CL000004','GP000019','b.riley@pupil.ac.uk','qNuGf2MagZ9',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000020','Maxwell','Buckley','CL000004','GP000020','m.buckley@pupil.ac.uk','KsenfCuqC3A',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000021','Emerson','Mayo','CL000004','GP000021','e.mayo@pupil.ac.uk','tUaTVm',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000022','Wylie','Garrett','CL000004','GP000022','w.garrett@pupil.ac.uk','Z33m9Y',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000023','Branden','Armstrong','CL000004','GP000023','b.armstrong@pupil.ac.uk','Ucq5qS',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000024','Carly','Brown','CL000004','GP000024','c.brown@pupil.ac.uk','6ZyB8u',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000025','Aline','Mcgowan','CL000004','GP000025','a.mcgowan@pupil.ac.uk','YeDYLq',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000026','Quemby','Boyle','CL000004','GP000026','q.boyle@pupil.ac.uk','MEBqZU',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000027','Jonas','Sargent','CL000003','GP000027','j.sargent@pupil.ac.uk','zBZrYM',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000028','Marvin','Fisher','CL000003','GP000028','m.fisher@pupil.ac.uk','TUHZjf',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000029','Caleb','Gallegos','CL000003','GP000029','c.gallegos@pupil.ac.uk','CqQPba',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000030','Sopoline','Justice','CL000003','GP000030','s.justice@pupil.ac.uk','3XWhXE',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000031','Nash','Rowe','CL000002','GP000031','n.rowe@pupil.ac.uk','b9YbJ7D',0);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000032','Duncan','Graham','CL000002','GP000032','d.graham@pupil.ac.uk','885dMgb',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000033','Xavier','Kim','CL000002','GP000033','x.kim@pupil.ac.uk','buhEd4p',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000034','Nita','Bauer','CL000002','GP000034','n.bauer@pupil.ac.uk','GuTRRYg',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000035','Bertha','Frost','CL000002','GP000035','b.frost@pupil.ac.uk','E7MBSEb',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000036','Ashley','Frost','CL000002','GP000035','a.frost@pupil.ac.uk','9pBvksW',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000037','Janine','Buckley','CL000002','GP000020','j.buckley@pupil.ac.uk','2zyuaJ5',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000038','Peter','Fisher','CL000002','GP000028','p.fisher@pupil.ac.uk','fsj2R76',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000039','Stephen','Lyons','CL000002','GP000002','s.lyons@pupil.ac.uk','XEVYug9',1);
INSERT INTO pupils (pupil_id, first_name, last_name, class_id, guardian_id, email, user_password, enrolled) VALUES ('PU000040','Stephen','Lamb','CL000001','GP000005','s.lamb@pupil.ac.uk','YUgLCjf',1);

INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000001','2016-03-29','ST000014');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000002','2016-03-27','ST000015');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000003','2016-03-21','ST000021');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000004','2016-04-04','ST000004');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000005','2016-04-07','ST000014');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000006','2016-04-07','ST000004');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000007','2016-04-08','ST000004');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000008','2016-04-08','ST000021');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000009','2016-04-09','ST000021');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000010','2016-04-09','ST000016');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000011','2016-04-10','ST000005');
INSERT INTO quiz (quiz_id, date_submitted, staff_id) VALUES ('QZ000012','2016-04-10','ST000005');

INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00001','Which is the correct order, starting with the smallest and ending with the largest?','PHAN0001','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00002','Which is the third planet from the sun?','PHAN0006','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00003','Which force keeps the planets in orbit?','PHAN0008','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00004','Why does an astronaut weigh less on the moon than on earth?','PHAN0012','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00005','What is the weight of a 20kg box on the Earth?','PHAN0014','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00006','The orbits of the planets are','PHAN0018','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00007','The further away from the sun','PHAN0021','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00008','Why is a day on mars about 37mins longer than a day on earth?','PHAN0023','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00009','In which direction does the Earth spin?','PHAN0025','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00010','Why do we have seasons on earth?','PHAN0030','QZ000001');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00011','What happens to the particles when a piece of rock Is heated up?','PHAN0031','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00012','What happenes to a bar of steel when it is cooled down?','PHAN0035','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00013','what happens to the pressure in a metal spray can when it is heated up?','PHAN0039','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00014','why do gases exert a pressure on the walls of their container?','PHAN0042','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00015','What process causes smelly gases to spread around a room on their own?','PHAN0044','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00016','In which state are atoms closest together (except water)?','PHAN0046','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00017','in which state do atoms have the most energy?','PHAN0051','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00018','what is the transition from a solid to a gas called?','PHAN0053','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00019','what happens to temperature when a state change occurs','PHAN0055','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00020','in which state is water most dense?','PHAN0058','QZ000004');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00021','Waves in water are what type?','PHAN0061','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00022','What are undulations?','PHAN0062','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00023','At what direction are the undulations in a transverse wave to its direction?','PHAN0069','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00024','What happens to water waves when they hit a surface?','PHAN0070','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00025','What happens to two waves that collide in step?','PHAN0074','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00026','What happens to two waves that collide out of step?','PHAN0078','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00027','What equipment can we use to show superposition?','PHAN0079','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00028','When does superposition occur?','PHAN0083','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00029','What is the amplitude of a wave?','PHAN0086','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00030','What do we use to model transverse waves?','PHAN0088','QZ000005');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00031','What is the pressure exerted by a man standing on one leg?','PHAN0093','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00032','The weight of a 100 N laser printer is spread over 0.5m2. What is the pressure it exerts?','PHAN0095','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00033','What are the correct units of pressure?','PHAN0097','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00034','How do you calculate pressure?','PHAN0101','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00035','What are the correct units of force?','PHAN0105','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00036','Which example increases pressure?','PHAN0106','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00037','Which example reduces pressure on the ground the most?','PHAN0111','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00038','What states of matter are fluids?','PHAN0114','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00039','Where is there greatest pressure?','PHAN0115','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00040','What is upthrust?','PHAN0119','QZ000006');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00041','What is the correct equation for calculating speed?','PHAN0123','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00042','What are the correct units for speed?','PHAN0125','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00043','What is the correct equation for calculating time?','PHAN0129','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00044','What is the correct equation for calculating distance?','PHAN0130','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00045','What does a horizontal line in a distance-time graph show?','PHAN0135','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00046','What does a steep line in a distance-time graph show?','PHAN0138','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00047','What does a gently sloping line in a distance-time graph show?','PHAN0139','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00048','What goes on the x-axis in a distance-time graph?','PHAN0143','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00049','How do you calculate the relative speed of objects moving in the same direction?','PHAN0145','QZ000007');
INSERT INTO physics_questions (physics_id, question, correct_answer, quiz_id) VALUES ('PHY00050','How do you calculate the relative speed of objects moving in the opposite direction?','PHAN0148','QZ000007');

INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0001','planet-star-galaxy',1,'PHY00001');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0002','planet-galaxy-star',0,'PHY00001');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0003','star-planet-galaxy',0,'PHY00001');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0004','mars',0,'PHY00002');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0005','venus',0,'PHY00002');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0006','earth',1,'PHY00002');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0007','friction',0,'PHY00003');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0008','gravity',1,'PHY00003');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0009','magneitc',0,'PHY00003');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0010','the moon has no atmosphere',0,'PHY00004');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0011','the moon has no gravity',0,'PHY00004');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0012','the force of gravity is weaker on the surface of the moon than on the surface of earth',1,'PHY00004');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0013','2N',0,'PHY00005');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0014','20N',1,'PHY00005');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0015','200N',0,'PHY00005');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0016','perfect circles',0,'PHY00006');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0017','slightly squashed circles',0,'PHY00006');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0018','spheres',1,'PHY00006');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0019','the faster the planet moves',0,'PHY00007');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0020','the hotter the planet is',0,'PHY00007');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0021','the longer the planets orbit takes',1,'PHY00007');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0022','martian watches dont keep a very good time',0,'PHY00008');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0023','Mars spins more slowly on its exis than Earth does',1,'PHY00008');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0024','Mars spins faste on its axis than Earth does',0,'PHY00008');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0025','From west to east',1,'PHY00009');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0026','From east to west',0,'PHY00009');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0027','From north to south',0,'PHY00009');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0028','the earth is closer to the sun in summer than it is in winter',0,'PHY00010');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0029','the sun is brighter in summer than it is in winter',0,'PHY00010');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0030','the sun is brighter in summer than it is in winter',1,'PHY00010');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0031','they get bigger',1,'PHY00011');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0032','they get smaller',0,'PHY00011');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0033','they stay the same size',0,'PHY00011');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0034','gets longer',0,'PHY00012');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0035','gets shorter',1,'PHY00012');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0036','stays the same length',0,'PHY00012');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0037','it increases',0,'PHY00013');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0038','it decreases',0,'PHY00013');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0039','it stays the same',1,'PHY00013');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0040','the gas particles hit each other',0,'PHY00014');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0041','the gas particles move quickly in all directions',0,'PHY00014');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0042','the gas particles hit the container walls',1,'PHY00014');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0043','Defusion',0,'PHY00015');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0044','diffusion',1,'PHY00015');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0045','diffraction',0,'PHY00015');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0046','solids',1,'PHY00016');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0047','liquids',0,'PHY00016');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0048','gases',0,'PHY00016');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0049','solids',0,'PHY00017');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0050','liquids',0,'PHY00017');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0051','gases',1,'PHY00017');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0052','solidifying',0,'PHY00018');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0053','sublimation',1,'PHY00018');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0054','melting',0,'PHY00018');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0055','nothing',1,'PHY00019');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0056','it increases',0,'PHY00019');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0057','it decreases',0,'PHY00019');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0058','solid',1,'PHY00020');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0059','liquids',0,'PHY00020');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0060','gas',0,'PHY00020');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0061','Transverse',1,'PHY00021');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0062','Longitudinal',0,'PHY00021');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0063','Light',0,'PHY00021');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0064','The number of waves per second',0,'PHY00022');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0065','Up and down movements',1,'PHY00022');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0066','The height of a wave',0,'PHY00022');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0067','360 degrees',0,'PHY00023');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0068','180 degrees',0,'PHY00023');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0069','90 degrees',1,'PHY00023');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0070','Reflection',1,'PHY00024');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0071','Refraction',0,'PHY00024');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0072','They stop',0,'PHY00024');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0073','Cancelling',0,'PHY00025');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0074','Adding',1,'PHY00025');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0075','Subtracting',0,'PHY00025');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0076','Multiplying',0,'PHY00026');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0077','Dividing',0,'PHY00026');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0078','Cancelling',1,'PHY00026');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0079','Ripple tank',1,'PHY00027');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0080','Fume cupboard',0,'PHY00027');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0081','Thermometer',0,'PHY00027');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0082','When waves miss each other',0,'PHY00028');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0083','When waves meet each other and interact',1,'PHY00028');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0084','When waves are started',0,'PHY00028');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0085','The distance between the same two points on a wave',0,'PHY00029');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0086','The maximum height of the wave',1,'PHY00029');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0087','The number of waves per second',0,'PHY00029');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0088','A rope',1,'PHY00030');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0089','A slinky spring',0,'PHY00030');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0090','A glass full of water with a straw in it',0,'PHY00030');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0091','Half of the pressure he exerts when standing on two legs',0,'PHY00031');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0092','Half of the pressure he exerts when standing on two legs',0,'PHY00031');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0093','Twice the pressure he exerts when standing on two legs',1,'PHY00031');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0094','50 N/m2',0,'PHY00032');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0095','200 N/m2',1,'PHY00032');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0096','500 N/m2',0,'PHY00032');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0097','Newtons per square metre',1,'PHY00033');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0098','Coulombs',0,'PHY00033');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0099','Newtons',0,'PHY00033');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0100','Area divided by force',0,'PHY00034');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0101','Force divided by area',1,'PHY00034');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0102','Force added to area',0,'PHY00034');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0103','Newtons per square metre',0,'PHY00035');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0104','Pascals',0,'PHY00035');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0105','Newtons',1,'PHY00035');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0106','A drawing pin',1,'PHY00036');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0107','Snowshoes',0,'PHY00036');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0108','A long lever',0,'PHY00036');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0109','Wearing high heels',0,'PHY00037');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0110','Wearing skis',0,'PHY00037');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0111','Lying down flat',1,'PHY00037');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0112','Liquids only',0,'PHY00038');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0113','Gases and solids',0,'PHY00038');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0114','Liquids and gases',1,'PHY00038');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0115','At the bottom of the ocean',1,'PHY00039');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0116','In the middle of the ocean',0,'PHY00039');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0117','At the surface of the ocean',0,'PHY00039');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0118','The same as gravity',0,'PHY00040');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0119','The force that water pushes floating objects up with',1,'PHY00040');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0120','A type of energy',0,'PHY00040');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0121','Distance multiplied by time',0,'PHY00041');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0122','Time divided by distance',0,'PHY00041');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0123','Distance divided by time',1,'PHY00041');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0124','Miles per hour',0,'PHY00042');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0125','Metres per second',1,'PHY00042');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0126','Kilometres per hour',0,'PHY00042');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0127','Distance subtracted from speed',0,'PHY00043');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0128','Distance multiplied by speed',0,'PHY00043');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0129','Distance divided by speed',1,'PHY00043');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0130','Speed multiplied by time',1,'PHY00044');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0131','Speed divided by time	',0,'PHY00044');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0132','Time divided by speed',0,'PHY00044');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0133','Fast moving',0,'PHY00045');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0134','Slow moving',0,'PHY00045');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0135','Stationary',1,'PHY00045');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0136','Stationary',0,'PHY00046');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0137','Slow moving',0,'PHY00046');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0138','Fast moving',1,'PHY00046');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0139','Slow moving',1,'PHY00047');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0140','Fast moving',0,'PHY00047');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0141','Stationary',0,'PHY00047');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0142','Distance',0,'PHY00048');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0143','Time',1,'PHY00048');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0144','Speed',0,'PHY00048');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0145','Fastest speed minus slowest speed',1,'PHY00049');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0146','Slowest speed minus fastest speed',0,'PHY00049');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0147','Slowest speed multiplied by fastest speed',0,'PHY00049');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0148','Add both speeds together',1,'PHY00050');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0149','Fastest speed minus slowest speed',0,'PHY00050');
INSERT INTO physics_answers (physics_answers_id, answers, correct_answer, physics_id) VALUES ('PHAN0150','Multiply both speeds together',0,'PHY00050');

INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00001','Where are blood cells made?','BIOA0003','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00002','Which part of the skeleton protects the lungs?','BIOA0005','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00003','What minerals makes bones strong','BIOA0009','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00004','What are the two bones in the lower arm called?','BIOA0011','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00005','What is the purpose of white blood cells?','BIOA0014','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00006','Which of these is a hinge joint?','BIOA0017','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00007','What is the smooth substance at the end of a bone called?','BIOA0019','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00008','What sort of joint is the hip joint?','BIOA0023','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00009','How are muscles attached to bones?','BIOA0027','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00010','Which two muscles are in your upper arm?','BIOA0028','QZ000002');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00011','What does exercise decrease?','BIOA0033','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00012','What is the addictive substance in tobacco smoke?','BIOA0034','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00013','Which of the main substances in tobacco smoke causes cancer?','BIOA0039','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00014','Which statement about drugs is correct?','BIOA0042','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00015','Which part of the gas exchange system does asthma affect?','BIOA0044','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00016','what happnes to the bronchioles during an asthma attack?','BIOA0047','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00017','Which of these is an example of a stimulant?','BIOA0051','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00018','which drug is illegal?','BIOA0052','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00019','Which drug is a depressant?','BIOA0056','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00020','which can be a long term effect of excessive alcohol?','BIOA0060','QZ000011');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00021','Who produced the first x-ray pictures of DNA?','BIOA0063','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00022','which of these is the smallest?','BIOA0064','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00023','where are the chromosomes found?','BIOA0068','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00024','which two scientists discovered the shape of DNA?','BIOA0072','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00025','What is the shape of DNA?','BIOA0073','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00026','which scientist did not win the nobel prize for their work on DNA?','BIOA0077','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00027','How many chromosomes do normal body cells have?','BIOA0081','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00028','How many chromosomes do sperm and eggs have?','BIOA0084','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00029','What is the definition of a gene?','BIOA0086','QZ000012');
INSERT INTO biology_questions (biology_id, question, correct_answer, quiz_id) VALUES ('BIO00030','How many genes do we have?','BIOA0090','QZ000012');

INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0001','Stomach',0,'BIO00001');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0002','Pancreas',0,'BIO00001');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0003','Bone Marrow',1,'BIO00001');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0004','The femur',0,'BIO00002');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0005','The rib cage',1,'BIO00002');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0006','the skull',0,'BIO00002');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0007','oxygen',0,'BIO00003');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0008','iron',0,'BIO00003');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0009','calcium',1,'BIO00003');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0010','Radius and ulna',0,'BIO00004');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0011','Tibia and fibula',1,'BIO00004');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0012','Femur and humerus',0,'BIO00004');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0013','to carry oxygen',0,'BIO00005');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0014','to protect against infection',1,'BIO00005');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0015','to speed up digestion',0,'BIO00005');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0016','shoulder',0,'BIO00006');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0017','hip',1,'BIO00006');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0018','knee',0,'BIO00006');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0019','Cartilage',1,'BIO00007');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0020','Tendon',0,'BIO00007');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0021','Ligament',0,'BIO00007');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0022','Hinge joint',0,'BIO00008');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0023','rotating joint',1,'BIO00008');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0024','ball and socket joint',0,'BIO00008');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0025','cartilage',0,'BIO00009');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0026','tendon',0,'BIO00009');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0027','ligament',1,'BIO00009');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0028','Biceps and tripceps',1,'BIO00010');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0029','Biceps and hamstrings',0,'BIO00010');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0030','hamstrings and quadriceps',0,'BIO00010');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0031','tidal volume',0,'BIO00011');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0032','breating rate',0,'BIO00011');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0033','the risk of a heart attack',1,'BIO00011');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0034','nicotine',1,'BIO00012');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0035','tar',0,'BIO00012');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0036','carbon monoxide',0,'BIO00012');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0037','carbon monoxide',0,'BIO00013');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0038','Carbon dioxide',0,'BIO00013');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0039','tar',1,'BIO00013');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0040','all drugs are medicines',0,'BIO00014');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0041','most drugs have no effect on the body',0,'BIO00014');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0042','alcohol and tobacco are legal drugs',1,'BIO00014');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0043','the mouth',0,'BIO00015');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0044','the bronchioles',1,'BIO00015');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0045','the capillaries',0,'BIO00015');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0046','the muscles in the lining relax',0,'BIO00016');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0047','the muscles in the lining contract',1,'BIO00016');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0048','less fluid Is produced',0,'BIO00016');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0049','alcohol',0,'BIO00017');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0050','solvents',0,'BIO00017');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0051','caffeine',1,'BIO00017');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0052','heroin',1,'BIO00018');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0053','caffeine',0,'BIO00018');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0054','nicotine',0,'BIO00018');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0055','cocaine',0,'BIO00019');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0056','alcohol',1,'BIO00019');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0057','nicotine',0,'BIO00019');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0058','weight gain',0,'BIO00020');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0059','rash around the nose and mouth',0,'BIO00020');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0060','increased risk of mental illness',1,'BIO00020');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0061','crick',0,'BIO00021');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0062','watson',0,'BIO00021');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0063','franklin',1,'BIO00021');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0064','gene',1,'BIO00022');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0065','chromosome',0,'BIO00022');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0066','genome',0,'BIO00022');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0067','in the cytoplasm',0,'BIO00023');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0068','in the nucleus',1,'BIO00023');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0069','in the membrane',0,'BIO00023');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0070','franklin and wilkins',0,'BIO00024');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0071','darwin and wallace',0,'BIO00024');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0072','watson and crick',1,'BIO00024');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0073','double helix',1,'BIO00025');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0074','x shaped',0,'BIO00025');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0075','spherical',0,'BIO00025');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0076','watson',0,'BIO00026');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0077','franklin',1,'BIO00026');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0078','wilkins',0,'BIO00026');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0079','46 pairs',0,'BIO00027');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0080','23',0,'BIO00027');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0081','23 pairs',1,'BIO00027');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0082','46',0,'BIO00028');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0083','23 pairs',0,'BIO00028');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0084','23',1,'BIO00028');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0085','one copy of all our dna',0,'BIO00029');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0086','a selection of dna that gives a characteristic',1,'BIO00029');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0087','a coiled up,x shaped section of dna',0,'BIO00029');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0088','23 pairs',0,'BIO00030');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0089','23',0,'BIO00030');
INSERT INTO biology_answers (biology_answers_id, answers, correct_answer, biology_id) VALUES ('BIOA0090','around 20,000',1,'BIO00030');

INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00001','Which of these three metals is the most reactive: potassium, iron or gold?','CHMA0001','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00002','Which of these three metals is the least reactive: iron, copper or platinum?','CHMA0006','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00003','Which gas is produced when magnesium reacts with hydrochloric acid?','CHMA0009','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00004','What is the test for hydrogen?','CHMA0012','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00005','What are the products when calcium reacts with nitric acid?','CHMA0015','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00006','What are the products when magnesium reacts with sulfuric acid?','CHMA0016','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00007','What type of reaction involves a more reactive metal pushing a less reactive metal out of a compound?','CHMA0021','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00008','What happens when zinc is added to a solution of copper sulfate?','CHMA0023','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00009','What happens when copper is added to a solution of magnesium chloride?','CHMA0026','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00010','What are the products when zinc is added to lead nitrate solution?','CHMA0028','QZ000003');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00011','What is at the centre of the Earth?','CHMA0032','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00012','What is the core of the Earth made from?','CHMA0035','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00013','What is the solid, outermost part of the Earth made from?','CHMA0039','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00014','Which layer of the Earth is a liquid?','CHMA0041','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00015','What gas makes up most of the atmosphere?','CHMA0043','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00016','What percentage of the atmosphere is oxygen?','CHMA0046','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00017','What percentage of the atmosphere is carbon dioxide?','CHMA0051','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00018','What is the formula of nitrogen?','CHMA0053','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00019','How much water is in the air?','CHMA0055','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00020','Which gas is present in the atmosphere that is needed by all animals in order to survive?','CHMA0059','QZ000008');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00021','Which is the best way to get salt from salty water?','CHMA0061','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00022','Pure water can be separated from inky water by simple distillation because:','CHMA0065','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00023','What is the correct order for obtaining salt from a mixture of sand and salt?','CHMA0067','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00024','Which method is usually used to separate coloured substances from each other?','CHMA0072','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00025','How could you separate iron filings from a mixture of iron and sulfur?','CHMA0073','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00026','In filtration, what name is used to describe the solid left in the filter paper?','CHMA0077','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00027','If you wanted to make pure drinking water from sea water, what process would you use?','CHMA0080','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00028','Crude oil can be separated into several liquids that have different boiling points. What is the name of this process?','CHMA0084','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00029','In chromatography, where are the spots of coloured substances placed?','CHMA0087','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00030','What is the name of the piece of paper at the end of a chromatography experiment?','CHMA0088','QZ000009');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00031','When methane burns in oxygen, carbon dioxide and water are made. Which is a reactant?','CHMA0091','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00032','copper oxide and carbon dioxide are made when copper carbonate is heated strongly. Which is produced?','CHMA0096','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00033','what name is given to the force that holds atoms together in a compound?','CHMA0097','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00034','what is another name for combustion','CHMA0101','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00035','combustion reactions always release energy. What word can be used to describe them?','CHMA0104','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00036','which of these is fond in the fire triangle and is therefor essential for combustion?','CHMA0106','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00037','What is a hyrdocarbon?','CHMA0110','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00038','what is produced when a hydrocarbon fuel burns in a very good supply of oxygen?','CHMA0114','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00039','Which type of combustion releases the most energy?','CHMA0115','QZ000010');
INSERT INTO chemistry_questions (chemistry_id, question, correct_answer, quiz_id) VALUES ('CHM00040','what name is given to a substance that speeds up a reaction without being used up or chemically changed?','CHMA0119','QZ000010');

INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0001','Potassium',1,'CHM00001');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0002','Iron',0,'CHM00001');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0003','Gold',0	,'CHM00001');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0004','Iron',0,'CHM00002');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0005','Copper',0,'CHM00002');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0006','Platinum',1,'CHM00002');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0007','Carbon dioxide',0,'CHM00003');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0008','Oxygen',0,'CHM00003');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0009','Hydrogen',1,'CHM00003');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0010','A burning splint goes out',0,'CHM00004');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0011','A burning splint burns more brightly',0,'CHM00004');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0012','A burning splint makes a squeaky pop sound',1,'CHM00004');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0013','Calcium chloride and hydrogen',0,'CHM00005');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0014','Calcium oxide and carbon dioxide',0,'CHM00005');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0015','Calcium nitrate and hydrogen',1,'CHM00005');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0016','Magnesium sulfate and hydrogen',1,'CHM00006');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0017','Magnesium nitrate and hydrogen',0,'CHM00006');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0018','Magnesium sulfate and water',0,'CHM00006');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0019','Oxidation',0,'CHM00007');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0020','Combustion',0,'CHM00007');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0021','Displacement',1,'CHM00007');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0022','Nothing happens',0,'CHM00008');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0023','The zinc displaces the copper',1,'CHM00008');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0024','The mixture catches on fire',0,'CHM00008');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0025','Chlorine is produced',0,'CHM00009');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0026','Nothing happens',1,'CHM00009');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0027','The copper displaces the magnesium.',0,'CHM00009');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0028','Zinc nitrate solution and lead',1,'CHM00010');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0029','There is no reaction',0,'CHM00010');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0030','Hydrogen and zinc nitrate',0,'CHM00010');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0031','The mantle',0,'CHM00011');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0032','The core',1,'CHM00011');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0033','The crust',0,'CHM00011');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0034','Zinc and carbon',0,'CHM00012');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0035','Iron and nickel',1,'CHM00012');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0036','Oxygen and silicon',0,'CHM00012');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0037','The mantle',0,'CHM00013');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0038','The atmosphere',0,'CHM00013');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0039','The crust',1,'CHM00013');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0040','The inner core',0,'CHM00014');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0041','The outer core',1,'CHM00014');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0042','The mantle',0,'CHM00014');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0043','Nitrogen',1,'CHM00015');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0044','Oxygen',0,'CHM00015');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0045','Argon',0,'CHM00015');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0046','21%',1,'CHM00016');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0047','16%',0,'CHM00016');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0048','33%',0,'CHM00016');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0049','5%',0,'CHM00017');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0050','1%',0,'CHM00017');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0051','0.04%',1,'CHM00017');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0052','N',0,'CHM00018');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0053','N2',1,'CHM00018');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0054','N3',0,'CHM00018');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0055','Varies depending on the weather',1,'CHM00019');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0056','1%',0,'CHM00019');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0057','5%',0,'CHM00019');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0058','Nitrogen',0,'CHM00020');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0059','Oxygen',1,'CHM00020');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0060','Argon',0,'CHM00020');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0061','Evaporation',1,'CHM00021');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0062','Filtration',0,'CHM00021');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0063','Distillation',0,'CHM00021');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0064','Water and ink have different boiling points',0,'CHM00022');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0065','Water evaporates leaving the ink particles behind',1,'CHM00022');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0066','Ink evaporates leaving the water behind',0,'CHM00022');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0067','Dissolving in water - filtration - evaporation',1,'CHM00023');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0068','Evaporation - filtration - dissolving in water',0,'CHM00023');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0069','Filtration - dissolving in water - evaporation',0,'CHM00023');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0070','Simple distillation',0,'CHM00024');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0071','Evaporation',0,'CHM00024');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0072','Chromatography',1,'CHM00024');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0073','Using a magnet',1,'CHM00025');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0074','By adding water and filtering',0,'CHM00025');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0075','By distillation',0,'CHM00025');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0076','Filtrate',0,'CHM00026');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0077','Residue',1,'CHM00026');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0078','Distillate',0,'CHM00026');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0079','Filtration',0,'CHM00027');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0080','Distillation',1,'CHM00027');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0081','Evaporation',0,'CHM00027');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0082','Simple distillation',0,'CHM00028');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0083','Chromatography',0,'CHM00028');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0084','Fractional distillation',1,'CHM00028');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0085','Randomly on the piece of paper',0,'CHM00029');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0086','In a vertical line on the paper',0,'CHM00029');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0087','On a horizontal line on the paper',1,'CHM00029');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0088','Chromatogram',1,'CHM00030');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0089','Filtrate',0,'CHM00030');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0090','Residue',0,'CHM00030');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0091','oxygen',1,'CHM00031');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0092','carbon dioxide',0,'CHM00031');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0093','water',0,'CHM00031');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0094','heat',0,'CHM00032');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0095','copper carbonate',0,'CHM00032');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0096','copper oxide',1,'CHM00032');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0097','chemical bond',1,'CHM00033');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0098','gravity',0,'CHM00033');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0099','electrostatic attraction',0,'CHM00033');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0100','reduction',0,'CHM00034');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0101','burning',1,'CHM00034');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0102','displacement',0,'CHM00034');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0103','endothermic',0,'CHM00035');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0104','exothermic',1,'CHM00035');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0105','reversible',0,'CHM00035');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0106','oxygen',1,'CHM00036');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0107','water',0,'CHM00036');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0108','carbon dioxide',0,'CHM00036');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0109','a compound that contain carbon and hydrogen',0,'CHM00037');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0110','a compound made from carbon and hydrogen only',1,'CHM00037');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0111','a compound that has been ontained from crude oil',0,'CHM00037');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0112','carbon monoxide and water',0,'CHM00038');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0113','carbon and water',0,'CHM00038');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0114','carbon dioxide and water',1,'CHM00038');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0115','complete combustion',1,'CHM00039');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0116','incomplete combustion',0,'CHM00039');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0117','thermal decomposition',0,'CHM00039');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0118','reducing agent',0,'CHM00040');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0119','catalyst',1,'CHM00040');
INSERT INTO chemistry_answers (chemistry_answers_id, answers, correct_answer, chemistry_id) VALUES ('CHMA0120','oxidising agent',0,'CHM00040');

INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000016','QZ000001','9','2016-03-29');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000017','QZ000001','8','2016-04-01');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000018','QZ000001','8','2016-04-03');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000001','QZ000001','7','2016-04-04');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000002','QZ000001','9','2016-04-01');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000003','QZ000001','5','2016-04-01');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000038','QZ000001','5','2016-04-08');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000039','QZ000001','2','2016-04-10');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000040','QZ000001','3','2016-04-14');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000035','QZ000001','1','2016-03-29');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000016','QZ000002','0','2016-04-01');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000017','QZ000002','1','2016-04-14');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000018','QZ000002','10','2016-04-09');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000032','QZ000002','10','2016-03-27');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000033','QZ000002','10','2016-04-09');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000034','QZ000002','4','2016-04-14');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000008','QZ000002','5','2016-03-27');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000009','QZ000002','4','2016-04-08');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000010','QZ000002','7','2016-04-08');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000011','QZ000002','6','2016-03-27');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000005','QZ000003','7','2016-03-22');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000006','QZ000003','7','2016-03-23');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000021','QZ000003','8','2016-03-23');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000022','QZ000003','8','2016-03-28');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000023','QZ000003','9','2016-04-01');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000024','QZ000003','10','2016-03-28');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000007','QZ000003','6','2016-03-28');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000016','QZ000003','8','2016-04-01');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000017','QZ000003','8','2016-04-02');
INSERT INTO score (pupil_id, quiz_id, score, date_taken) VALUES ('PU000001','QZ000003','4','2016-03-21');

/* CREATE A VIEW THAT UNIONS ALL QUESTION TABLES */
CREATE VIEW questions
AS
SELECT
	physics_id as id,
    question as question,
    quiz_id as quiz_id,
    'physics' as category
FROM physics_questions
UNION ALL
SELECT
	biology_id as id,
    question as question,
    quiz_id as quiz_id,
    'biology' as category
FROM biology_questions
UNION ALL
SELECT
	chemistry_id as id,
    question as question,
    quiz_id as quiz_id,
    'chemistry' as category
FROM chemistry_questions;

/* CREATE A VIEW THAT UNIONS ALL ANSWERS TABLES */
CREATE VIEW answers
AS
SELECT
	biology_answers_id as id,
    answers as answer,
    correct_answer as correct_answer,
    biology_id as question_id
FROM biology_answers
UNION ALL
SELECT
	chemistry_answers_id as id,
    answers as answer,
    correct_answer as correct_answer,
    chemistry_id as question_id
FROM chemistry_answers
UNION ALL
SELECT
	physics_answers_id as id,
    answers as answer,
    correct_answer as correct_answer,
    physics_id as question_id
FROM physics_answers;

CREATE VIEW quiz_by_category
AS
SELECT
	quiz.quiz_id as quiz_id,
    quiz.date_submitted as date_submitted,
    quiz.stafF_id as staff_id,
    questions.category as category
FROM quiz
INNER JOIN questions on (quiz.quiz_id = questions.quiz_id)
GROUP BY
	quiz.quiz_id;
