package quiz;

public class Teacher {

}
