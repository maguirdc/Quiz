package quiz;

import java.util.ArrayList;

public class QuestionCreation {
	
	public ArrayList<Question> newQuestionBank(Question q){
		
		ArrayList<Question> questionBank = new ArrayList<>();
	
		questionBank.add(q);
			
		return questionBank;
	}

}
